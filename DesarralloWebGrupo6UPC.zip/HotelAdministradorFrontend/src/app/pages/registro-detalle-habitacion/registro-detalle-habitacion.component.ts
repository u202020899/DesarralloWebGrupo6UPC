import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-detalle-habitacion',
  templateUrl: './registro-detalle-habitacion.component.html',
  styleUrls: ['./registro-detalle-habitacion.component.css']
})
export class RegistroDetalleHabitacionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
