import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tipo-habitacion',
  templateUrl: './tipo-habitacion.component.html',
  styleUrls: ['./tipo-habitacion.component.css']
})
export class TipoHabitacionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
